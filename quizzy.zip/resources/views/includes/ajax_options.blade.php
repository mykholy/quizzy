{!! Form::select($name,$data,null, array('placeholder' => $placeholder,'class' => 'form-control select2 select2-hidden-accessible','required'=>'required', 'ui-jp'=>"select2",'ui-options'=>"{theme: 'bootstrap'}"  )) !!}


