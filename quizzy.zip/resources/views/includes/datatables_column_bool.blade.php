
<span class="me-1 badge bg-{{$value?'success':'danger'}}">{{__('lang.'.($value?'active':'not_active'))}}</span>
