<?php

return [
    'singular' => 'Car',
    'plural' => 'Cars',
    'fields' => [
        'id' => 'Id',
        'name' => 'Name',
        'photo' => 'Photo',
        'tags' => 'Models',
        'is_active' => 'Is Active',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ],
];
