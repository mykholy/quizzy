<?php

return [
    'not_found'=>'Not Found',
    'saved'=>'Added successfully for :model',
    'updated'=>'Updated successfully for :model',
    'deleted' => 'Deleted successfully for :model',

];
